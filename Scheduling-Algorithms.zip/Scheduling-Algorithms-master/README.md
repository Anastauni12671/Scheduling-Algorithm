# Scheduling-Algorithms
Our project is totally based on Scheduling Algorithms. We implemented the some algorithms in C. User will be asked to enter which scheduling algorithm he wants to run. The one he will choose, will be executed.
